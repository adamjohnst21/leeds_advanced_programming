"""
Assignment 2 program
Produces Map and .txt Reports for pubs within 30 minutes of Jonny's office

Author: 9466841

"""

### IMPORT LIBRARIES ###
from __future__ import print_function
from pyproj import Geod, Proj, transform
import fiona, mapnik
import networkx as nx
from shapely.geometry import LineString, mapping, shape, Polygon, Point
from osm2nx import read_osm
from PIL import Image, ImageDraw, ImageFont
import Tkinter
import tkMessageBox
import time
import scipy.stats as ss
from operator import mul, add
import operator
from math import ceil
from scalebar import addScaleBar

#Starts timer for working out program run time
start_time = time.time()



### DEFINE FUNCTIONS ###

def findPubs(feat):
    
    """
    Determine whether we will be able to get a drink at the polygon based on it's amenity attribute
    """
    
    #return polygon if it serves alcohol
    return feat[1]['properties']['amenity'] == 'pub' or feat[1]['properties']['amenity'] == 'bar' or feat[1]['properties']['amenity'] == 'biergarten'


def pubScore(opLengths, ptLengths):

    """
    returns the rankings list for pubs based on their suitability.
    It accounts for proximity to MCO station from the pub and the overall, office-pub-station distance
    Pubs closer to MCO station and with shorter overall distance are more preferable, and ranked first
    """

    #Add the office-Pub distance to pub-MCO distance for total travel distance
    tDist = list(map(add, opLengths, ptLengths))
        
        
    #return a ranked list of pub score, based on pub-mco dist * total distance
    return list(ss.rankdata(list(map(mul, ptLengths, tDist))))



### FILTER OUT PUBS ###

#Open Jonny's office point
with fiona.open('./data/manchester/jonnysoffice.shp') as jO:

    #get the office coordinates
    jOffice = jO[0]['geometry']['coordinates']
    
    

#set the maximum distance of the pubs, based on the maximum distance possibly covered in half an hour
maxDist = (5000/2)

#Get the length of the bounding box
diagBox = maxDist * (2**0.5)

#set the ellipsoid to BNG
g = Geod(ellps='airy')

#open the buildings file
with fiona.open('./data/manchester/osm_polygons.shp') as mPolys:

    # use forward Vincenty method to get end point from distance and direction (bottom left)
    blX, blY, bAz = g.fwd(jOffice[0], jOffice[1], 225, diagBox)
    trX, trY, bAz = g.fwd(jOffice[0], jOffice[1], 45,  diagBox)
	
    # get all polygons within bounding box around the envelope using the spatial index in the .shx file
    roiPoints = list(mPolys.items(bbox=(blX, blY, trX, trY)))


    #filter the pubs with tag and bounding box, then save into a list
    pubList = list(filter(findPubs, roiPoints))



### FIND PUB ROUTES ###

#Convert the Manchester XML into a networkX graph
G, idx = read_osm('./data/manchester/manchester.xml')

#set the starting node as Jonny's office
fromNode = str(list(idx.nearest((jOffice[0], jOffice[1], jOffice[0], jOffice[1]), 1))[0])

#list to hold names of pubs that a route cannot be calculated for
noRoute = []

#list to hold names of pubs outside the 2500m walking distance
tooLongRoute = []

#list to hold lengths of routes that are over 2500m
tlrLength = []

#list to hold the walkable pub polygon data in
wPubPolygons = []

#create file for pub routes
with fiona.open('./data/shapefiles/routes.shp', 'w',	driver='ESRI Shapefile', crs=mPolys.crs, 
		schema={'geometry': 'LineString', 'properties': {'name':'str', 'length':'int'}}) as ls:
    
    #loop through each pub in the bounding box
    for i in pubList:

        #variable to store pub name in
        name = i[1]['properties']['name']
        
        
        #set the end point as the centroid of each pub
        toNode = str(list(idx.nearest(((mapping(shape(i[1]['geometry']).centroid))['coordinates']), 1))[0])

        #if there is a path between the office and the pub
        if nx.has_path(G, source=fromNode, target=toNode):

            #find the shortest path between them
            shortestPath = nx.astar_path(G, source=fromNode, target=toNode, weight='distance')
            
            #Variable to hold linestring
            line = []

            #loop through each node in the path and ass it to line list
            for n in shortestPath:

                #get the relevant node from graph
                node = G.subgraph(n).nodes(data=True)

                #add the lat long data to the linestring
                line.append([node[0][1]['lon'], node[0][1]['lat']])

            #store this as a line string, converting to fiona format
            routeShape = mapping(LineString(line))

            #set the cumulative length variable
            cumulativeLength = 0

            #loop through each segment of the linestring, calculcating ellipsoidal distance and adding to cumulative length
            for lineSeg in range(len(routeShape['coordinates'])-1):
                
                #get distance between two coordinates using inverse vincenty
                azF,azB,distance = g.inv(routeShape['coordinates'][1][0], routeShape['coordinates'][1][1], routeShape['coordinates'][1+1][0], routeShape['coordinates'][1+1][1])

                #add each distance to the cumulative length
                cumulativeLength += distance

            #determine if the route is within the 30 minute walking distance
            if cumulativeLength <= 2500:

                #write save the walkable pub polygon into separate list
                wPubPolygons.append(i)
            
                #Write the route to the routes.shp file
                ls.write({'geometry': (routeShape), 'properties': {'name': i[1]['properties']['name'], 'length': cumulativeLength} })

            #if pub is over 2500m, save it's name to a different list (else statement)
            else:
                tooLongRoute.append(name)
                tlrLength.append(cumulativeLength)
                

        #if a route can't be calculated, add pub name to list (else statement)
        else:
            noRoute.append(name)
            
  

##Creating a list of route lengths
#open the routes file
with fiona.open('./data/shapefiles/routes.shp') as r:
    
    
    #list to hold the lengths of routes to pub from office
    opLengths= []

    #loop through each pub route
    for n in r:


        #loop through each route, adding it to the length list
        opLengths.append(n['properties']['length'])
        
    


    
        


### ROUTES FROM THE PUB TO MANCHESTER OXFORD ROAD ###


#List to hold any pubs that no route to MCO could be found
noRoutei = []

#node for Manchester Oxford Road station
mcoNode = str(list(idx.nearest((-2.241511, 53.474603, -2.241511, 53.474603), 1))[0])

#create file for pub routes
with fiona.open('./data/MCOroutes.shp', 'w',	driver='ESRI Shapefile', crs=mPolys.crs, 
		schema={'geometry': 'LineString', 'properties': {'name':'str', 'length':'int'}}) as lsi:
    
    #loop through each pub  walkable in 30 mins
    for i in wPubPolygons:

        #variable to store pub name in
        names = i[1]['properties']['name']
        
        
        #set the end point as the centroid of each pub
        pubNode = str(list(idx.nearest(((mapping(shape(i[1]['geometry']).centroid))['coordinates']), 1))[0])

        #if there is a path between the pub and MCO
        if nx.has_path(G, source=mcoNode, target=pubNode):

            #find the shortest path between them
            shortestPath = nx.astar_path(G, source=mcoNode, target=pubNode, weight='distance')

            line = []

            #loop through each node in the path and ass it to line list
            for n in shortestPath:

                #get the relevant node from graph
                node = G.subgraph(n).nodes(data=True)

                #add the lat long data to the linestring
                line.append([node[0][1]['lon'], node[0][1]['lat']])

            #store this as a line string, converting to fiona format
            routeShape = mapping(LineString(line))

            #set the cumulative length variable
            cumulativeLength = 0

            #loop through each segment of the linestring, calculcating ellipsoidal distance and adding to cumulative length
            for lineSeg in range(len(routeShape['coordinates'])-1):
                
                #get distance between two coordinates using inverse vincenty
                azF,azB,distance = g.inv(routeShape['coordinates'][1][0], routeShape['coordinates'][1][1], routeShape['coordinates'][1+1][0], routeShape['coordinates'][1+1][1])

                #add each distance to the cumulative length
                cumulativeLength += distance
            

            #Write the route to the MCOroutes.shp file
            lsi.write({'geometry': (routeShape), 'properties': {'name': i[1]['properties']['name'], 'length': cumulativeLength} })



        #if a route can't be calculated, add pub name to list (else statement)
        else:
            noRoutei.append(name)






### PUB RANKING ###

#Create a list of office-pub route lengths
with fiona.open('./data/shapefiles/routes.shp') as r:
    
    
    #list to hold the lengths of routes to pub from office
    opLengths= []

    #loop through each pub route
    for n in r:


        #loop through each route, adding it to the length list
        opLengths.append(n['properties']['length'])

        
#Create a list of pub-MCO route lengths
with fiona.open('./data/MCOroutes.shp') as trn:

    ptLengths = []

    #Loop through each pub
    for t in trn:

        #loop through each route adding it to the lenth list
        ptLengths.append(t['properties']['length'])



#Retrive list of pub rankings from pubScore function            
pScores =  pubScore(opLengths, ptLengths)

#List of rankings as whole numbers (So that when later compared to [i] number, ranks such as 4.5 are added)
scores = [int(round(n, 0)) for n in pScores]




#create new shapefile for walkable pubs
with fiona.open('./data/shapefiles/walkable_pubs.shp', 'w',	driver='ESRI Shapefile', crs=mPolys.crs, 
		schema={'geometry': 'Polygon', 'properties': {'name':'str', 'rank':'float', 'distance':'float'}}) as sf:

    #create loop to go through each level in the wPubPolygons list
    for i in range(len(wPubPolygons)):
        
        #access level [i] for wPubPulygons
    	f = wPubPolygons[i]

    	#Write that level wPubPolygons data and the same level in the 'scores' list
    	sf.write({'geometry': f[1]['geometry'], "properties":{'name': f[1]['properties']['name'], 'rank': scores[i], 'distance': opLengths[i]}})



#Create an ordered list of pubs based on their suitability ranking
with fiona.open('./data/shapefiles/walkable_pubs.shp') as p:

    #List to hold ordered pubs in fiona format
    orderedPubs = []

    #+1 as range starts from 0, so range wouldn't cover rank 30
    for i in range((len(p)+1)):

        #Loop through all the walkable pub polygons
        for k in p:

            #as i loops through 1,2,3 etc, when pub rank = this, it is added into list, therefore creating list in rank order
            if i == k['properties']['rank']:
                orderedPubs.append(k)
                

        

### CREATE PROGRAM REPORT AND PUB RECOMMENDATIONS ###


#Creates a .txt file with program results
with open('./outputs/Program_report.txt','w') as r:
    print('9466841 PROGRAM REPORT', file=r)
    print (file=r)
    print ('There are', len(pubList), 'pubs within the 2500m bounding box filter', file=r)
    print ('No route could be calculated for', len(noRoute), 'pubs, the', noRoute[0], 'and the', noRoute[1], file=r)
    print (file=r)
    print (len(tooLongRoute), 'pubs are too far to walk in 30 minutes, including:', file=r)
    for i in range(len(tooLongRoute)):
        print (tooLongRoute[i], 'is', ceil((tlrLength[i]/83)-30), 'minutes longer than the acceptable walk', file=r)
    print (file=r)
    print (len(wPubPolygons), 'pubs were identified to be within a 30 minute walk. This includes:', file=r)
    with fiona.open('./data/shapefiles/routes.shp') as rf:
        for n in rf:
            print ('It takes', ((n['properties']['length'])/83), 'minutes to walk to the', n['properties']['name'], file=r)
    print (file=r)
    print ('Routes were calculated to MCO station for', (33-len(noRoutei)), 'of the 33 pubs walkable from the office', file=r)
    with fiona.open('./data/MCOroutes.shp') as tr:
        for n in tr:
            print('It takes', ((n['properties']['length'])/83), 'minutes to walk to the station from', n['properties']['name'], file=r)

#creates a .txt file with information on pub rankings
with open('./outputs/Pub_recommendations.txt','w') as g:
    print('9466841 PUB RECOMMENDATIONS', file=g)
    print(file=g)
    print('Its a long taxi drive home from Manchester, so you are best catching the train to Lancaster from', file=g)
    print('Manchester Oxford Road station (MCO). After marking all of these assignments, you will be needing', file=g)
    print('more than a few pints. So ideally you want this pub to be close to MCO to minimise the stumbling', file=g)
    print('distance when you are done.', file=g)
    print(file=g)
    print('Fortunately Ive ranked pubs based on their suitability to these needs, after all, less time spent', file=g)
    print('deciding is more time for drinking. The list accounts for both the pubs proximity to MCO and the', file=g)
    print('overall distance you would travel from office-pub-MCO. Pubs that are both close to MCO and have a', file=g)
    print('lower overall travel distance are ranked the highest.', file=g)
    print(file=g)
    print('Pubs from most to least suitable:', file=g)
    for i in orderedPubs:
        print(i['properties']['rank'], i['properties']['name'], file=g)
    print(file=g)
    print('For any further information needed for individual pubs, such as journey travel times, please', file=g)
    print('consult the Program_results document', file=g)


   
###Shapefiles for map ###

#Create a point file for walkable pubs
with fiona.open('./data/shapefiles/walkable_pubs.shp') as s:
    
    with fiona.open('./data/shapefiles/pub_points.shp', 'w',	driver='ESRI Shapefile', crs=mPolys.crs, 
                    schema={'geometry': 'Point', 'properties': {'name':'str', 'rank':'float'}}) as sf:

        #create loop to go through each of the pub polygons
        for i in s:
        
            #Write that convert the polygon data into point geometry and keep properties
            sf.write({'geometry': mapping(shape(i['geometry']).centroid), "properties":{'name': i['properties']['name'], 'rank': i['properties']['rank']}})

    #Set the bounds for map zoom based on pub polygons        
    b = s.bounds

#Create a point file for the MCO station symbol
with fiona.open('./data/shapefiles/MCO_point.shp', 'w',    driver='ESRI Shapefile', crs=mPolys.crs, 
                schema={'geometry': 'Point', 'properties': {}}) as ts:

    #Variable to hold MCO coordinates in, converting to point geometry
    coords = Point([(-2.242308, 53.473956)])
    
    #Write geometry in fiona format
    ts.write({'geometry': mapping(coords), "properties":{}})

    


  
### CREATING THE MAP ###
    
# Create a map to draw to and set background	
m = mapnik.Map(1000, 1000)
m.background = mapnik.Color(73,88,94)

# The srs set to OS BNG
osgb = '+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs'
m.srs = osgb


#layer styles

# Set pub style
s = mapnik.Style()
r = mapnik.Rule()
ps = mapnik.PointSymbolizer()
ts = mapnik.TextSymbolizer()
ps.filename = './data/svg/Beer.svg'
ps.allow_overlap = True
t = mapnik.TextSymbolizer(mapnik.Expression('[rank]'), 'DejaVu Sans Bold', 8, mapnik.Color('black'))
t.allow_overlap = True
ps.transform = "scale(0.05)"
r.symbols.append(ps)
s.rules.append(r)
m.append_style('pStyle',s)


# Set Jonny's office style
s = mapnik.Style()
r = mapnik.Rule()
ps = mapnik.PointSymbolizer()
ps.filename = './data/svg/Office.svg'
ps.allow_overlap = True
ps.transform = "scale(0.05)"
r.symbols.append(ps)
s.rules.append(r)
m.append_style('jStyle',s)

# Set MCO train station style
s = mapnik.Style()
r = mapnik.Rule()
ps = mapnik.PointSymbolizer()
ps.filename = './data/svg/Train.svg'
ps.allow_overlap = True
ps.transform = "scale(0.06)"
r.symbols.append(ps)
s.rules.append(r)
m.append_style('tStyle',s)

# Set road style
roads_s = mapnik.Style()
roads_r = mapnik.Rule()
roads_r.symbols.append(mapnik.PolygonSymbolizer(mapnik.Color(73, 88, 94))) #Polygon is set to map background as it doesn't represent road network
roads_r.symbols.append(mapnik.LineSymbolizer(mapnik.Color(240, 255, 86), 1))
roads_s.rules.append(roads_r)
m.append_style('rdStyle',roads_s)

# Set buildings style
building_s = mapnik.Style()
building_r = mapnik.Rule()
building_r.symbols.append(mapnik.PolygonSymbolizer(mapnik.Color(181, 206, 206)))
building_r.symbols.append(mapnik.LineSymbolizer(mapnik.Color('white'), 0.5))
building_s.rules.append(building_r)
m.append_style('bStyle',building_s)

# Set style for routes
route_s = mapnik.Style()
route_r = mapnik.Rule()
route_r.symbols.append(mapnik.LineSymbolizer(mapnik.Color(68, 39, 186), 3))
route_s.rules.append(route_r)
m.append_style('rtStyle',route_s)


# Map layers, in order they are drawn

# Roads Layer
roads_ds = mapnik.Shapefile(file='./data/manchester/GM_shapes/gis.osm_roads_free_1.shp')
roads_l = mapnik.Layer('Roads')
roads_l.datasource = roads_ds
roads_l.styles.append('rdStyle')
m.layers.append(roads_l)


# Buildings layers
building_ds = mapnik.Shapefile(file='./data/manchester/GM_shapes/gis.osm_buildings_a_free_1.shp')
building_l = mapnik.Layer('Buildings')
building_l.datasource = building_ds
building_l.styles.append('bStyle')
m.layers.append(building_l)

# Jonny's office layer
layer = mapnik.Layer('jOffice')
layer.datasource = mapnik.Shapefile(file='./data/manchester/jonnysoffice.shp')
layer.styles.append('jStyle')
m.layers.append(layer)

# MCO train station layer
layer = mapnik.Layer('MCO')
layer.datasource = mapnik.Shapefile(file='./data/shapefiles/MCO_point.shp')
layer.styles.append('tStyle')
m.layers.append(layer)

# Pubs layer
layer = mapnik.Layer('Pubs')
layer.datasource = mapnik.Shapefile(file='./data/shapefiles/pub_Points.shp')
layer.styles.append('pStyle')
m.layers.append(layer)

# pub route layer (last so that nothing obstructs/hides route)
layer = mapnik.Layer('Routes')
layer.datasource = mapnik.Shapefile(file='./data/shapefiles/routes.shp')
layer.styles.append('rtStyle')
m.layers.append(layer)




### MAP REFINEMENT ###

# transform boundaires to BNG
p1 = Proj(init='epsg:4326')
p2 = Proj(init='epsg:27700')
x1, y1 = transform(p1,p2,b[0],b[1])
x2, y2 = transform(p1,p2,b[2],b[3])

# zoom the map with buffer
buffer = 250
m.zoom_to_box(mapnik.Box2d(x1-buffer,y1-buffer,x2+buffer,y2+buffer))
		
# render to file and open in PIL
mapnik.render_to_file(m, './outputs/pubs.png', 'png')
mapImg = Image.open('./outputs/pubs.png')

# open and paste north arrow
northArrow = Image.open('./data/svg/north17.png').resize((75,200), Image.ANTIALIAS)
mapImg.paste(northArrow, (5, 750), northArrow)

#Draw title
draw = ImageDraw.Draw(mapImg)
title = 'Pubs within 30 mins of Jonnys office'
tw, th = draw.textsize(title)
tFont = ImageFont.truetype('./data/open-sans/OpenSans-ExtraBoldItalic.ttf', 30)
draw.text((m.width-320-tw, m.height-935-th), title, fill=(0,0,0), font=tFont)

#Draw copyright notice
Attribute = 'Data Copyright OpenStreetMap Contributors'
aw, ah = draw.textsize(Attribute)
aFont = ImageFont.truetype('./data/open-sans/OpenSans-Regular.ttf', 12)
draw.text((m.width-20-aw, m.height-20-ah), Attribute, fill=(0,0,0), font=aFont)

# add a scalebar to the map
addScaleBar(m, mapImg, True)

#Show the map         
mapImg.show()


        
#Create dialog box when program complete with time taken to run
window = Tkinter.Tk()
window.wm_withdraw()
tkMessageBox.showinfo(title="Finished", message=("Program took %s seconds to run. Check output file for reports and map" % (time.time() - start_time)))
